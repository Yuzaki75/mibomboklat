Replace the Content of

/var/www/paymenter/app/Extensions/Servers/Pterodactyl/Pterodactyl.php

with the file in v0 (for paymenter v0.xxx) or v1 (for paymenter v1.xxx)
run

cd /var/www/paymenter && php artisan queue:restart

to apply the changes