Thank you for your purchase!
Downloaded addon: Server Splitter 1.1.4
Author: 0x7d8

(i) BLUEPRINT: (https://blueprint.zip/)
View the README.blueprint.txt file for instructions on how to install the addon using blueprint

(i) STANDALONE: (ainx)
View the README.standalone.txt file for instructions on how to install the addon using ainx (for standalone installations)

MIGRATION FROM BAGOU
You can migrate your Server splits from bagou by installing the addon and running
  php artisan tinker -n import-from-bagou-splitter.php