1. Place the `vanillatweaks.blueprint` file into your Pterodactyl instance directory (typically `/var/www/pterodactyl`) on your panel server.  
2. Execute the command `blueprint -install vanillatweaks`
3. Done <3
